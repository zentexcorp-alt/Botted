const { ChartJSNodeCanvas } = require('chartjs-node-canvas');

const width = 800;
const height = 400;
const chartCanvas = new ChartJSNodeCanvas({ width, height, backgroundColour: '#1a1a2e' });

/**
 * Generate a candlestick-style chart using bar datasets.
 */
async function generateCandlestickChart(asset) {
  const history = asset.priceHistory.slice(-30); // last 30 candles
  if (history.length < 2) return null;

  const labels = history.map((_, i) => `${i + 1}`);
  const opens = history.map((h) => h.open);
  const closes = history.map((h) => h.close);
  const highs = history.map((h) => h.high);
  const lows = history.map((h) => h.low);

  const candleColors = history.map((h) =>
    h.close >= h.open ? 'rgba(0, 255, 127, 0.85)' : 'rgba(255, 69, 69, 0.85)'
  );

  const config = {
    type: 'bar',
    data: {
      labels,
      datasets: [
        {
          label: 'Price Range (High-Low)',
          data: history.map((h, i) => ({ x: i, y: [h.low, h.high] })),
          backgroundColor: candleColors.map((c) => c.replace('0.85', '0.3')),
          borderColor: candleColors,
          borderWidth: 1,
          barPercentage: 0.2,
          parsing: false,
        },
        {
          label: 'Open-Close',
          data: history.map((h, i) => ({ x: i, y: [h.open, h.close] })),
          backgroundColor: candleColors,
          borderColor: candleColors,
          borderWidth: 1,
          barPercentage: 0.6,
          parsing: false,
        },
      ],
    },
    options: {
      responsive: false,
      animation: false,
      plugins: {
        legend: { display: false },
        title: {
          display: true,
          text: `${asset.symbol} — Candlestick Chart`,
          color: '#e0e0e0',
          font: { size: 18, weight: 'bold' },
        },
      },
      scales: {
        x: {
          ticks: { color: '#aaa', maxTicksLimit: 10 },
          grid: { color: 'rgba(255,255,255,0.05)' },
        },
        y: {
          ticks: {
            color: '#aaa',
            callback: (v) => `$${v.toLocaleString()}`,
          },
          grid: { color: 'rgba(255,255,255,0.08)' },
        },
      },
    },
  };

  return chartCanvas.renderToBuffer(config);
}

/**
 * Generate a mountain (area) chart.
 */
async function generateMountainChart(asset) {
  const history = asset.priceHistory.slice(-60);
  if (history.length < 2) return null;

  const closes = history.map((h) => h.close);
  const labels = history.map((_, i) => `${i + 1}`);
  const isUp = closes[closes.length - 1] >= closes[0];
  const lineColor = isUp ? '#00ff7f' : '#ff4545';
  const fillColor = isUp ? 'rgba(0,255,127,0.15)' : 'rgba(255,69,69,0.15)';

  const config = {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: asset.name,
          data: closes,
          borderColor: lineColor,
          backgroundColor: fillColor,
          fill: true,
          tension: 0.4,
          pointRadius: 0,
          borderWidth: 2.5,
        },
      ],
    },
    options: {
      responsive: false,
      animation: false,
      plugins: {
        legend: { display: false },
        title: {
          display: true,
          text: `${asset.symbol} — ${asset.name} Price`,
          color: '#e0e0e0',
          font: { size: 18, weight: 'bold' },
        },
      },
      scales: {
        x: {
          ticks: { color: '#aaa', maxTicksLimit: 8 },
          grid: { color: 'rgba(255,255,255,0.05)' },
        },
        y: {
          ticks: {
            color: '#aaa',
            callback: (v) => `$${v.toLocaleString()}`,
          },
          grid: { color: 'rgba(255,255,255,0.08)' },
        },
      },
    },
  };

  return chartCanvas.renderToBuffer(config);
}

module.exports = { generateCandlestickChart, generateMountainChart };
