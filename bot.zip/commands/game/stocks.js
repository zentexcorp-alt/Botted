const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getOrCreateUser, formatMoney, formatPercent, priceChange } = require('../../utils/helpers');
const { recordTradePressure } = require('../../utils/marketEngine');
const Asset = require('../../models/Asset');
const Transaction = require('../../models/Transaction');
const { checkLevelUp } = require('../../utils/jobs');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stocks')
    .setDescription('Stock trading')
    .addSubcommand((sub) => sub.setName('list').setDescription('List all stocks'))
    .addSubcommand((sub) =>
      sub
        .setName('price')
        .setDescription('Check stock price')
        .addStringOption((o) => o.setName('symbol').setDescription('Stock ticker').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('buy')
        .setDescription('Buy shares')
        .addStringOption((o) => o.setName('symbol').setDescription('Ticker').setRequired(true))
        .addNumberOption((o) => o.setName('amount').setDescription('USD to spend').setRequired(true).setMinValue(1))
    )
    .addSubcommand((sub) =>
      sub
        .setName('sell')
        .setDescription('Sell shares')
        .addStringOption((o) => o.setName('symbol').setDescription('Ticker').setRequired(true))
        .addNumberOption((o) => o.setName('shares').setDescription('Shares to sell').setRequired(true).setMinValue(0.000001))
    )
    .addSubcommand((sub) => sub.setName('portfolio').setDescription('View your stock portfolio')),

  async execute(interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      const assets = await Asset.find({ type: 'stock', active: true }).sort({ marketCap: -1 });
      if (assets.length === 0) return interaction.editReply('❌ No stocks listed yet. Ask an admin to add some!');

      const lines = assets.map((a) => {
        const chg = priceChange(a.currentPrice, a.previousPrice);
        const arrow = chg >= 0 ? '🟢' : '🔴';
        return `${arrow} **${a.symbol}** (${a.name}) — ${formatMoney(a.currentPrice)} (${formatPercent(chg)}) | Sector: ${a.sector}`;
      });

      const embed = new EmbedBuilder()
        .setColor(0x1e90ff)
        .setTitle('📈 Stock Market')
        .setDescription(lines.join('\n'))
        .setFooter({ text: 'Prices update every minute' })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'price') {
      const symbol = interaction.options.getString('symbol').toUpperCase();
      const asset = await Asset.findOne({ symbol, type: 'stock', active: true });
      if (!asset) return interaction.editReply(`❌ Stock **${symbol}** not found.`);

      const chg = priceChange(asset.currentPrice, asset.previousPrice);
      const chg24 = asset.openPrice ? priceChange(asset.currentPrice, asset.openPrice) : 0;

      const embed = new EmbedBuilder()
        .setColor(chg >= 0 ? 0x00ff88 : 0xff4545)
        .setTitle(`📈 ${asset.name} (${asset.symbol})`)
        .addFields(
          { name: 'Price', value: formatMoney(asset.currentPrice), inline: true },
          { name: '1m Change', value: formatPercent(chg), inline: true },
          { name: '24h Change', value: formatPercent(chg24), inline: true },
          { name: 'Market Cap', value: formatMoney(asset.marketCap), inline: true },
          { name: 'Sector', value: asset.sector, inline: true },
          { name: '24h Volume', value: formatMoney(asset.totalVolume24h), inline: true }
        );

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'buy') {
      const symbol = interaction.options.getString('symbol').toUpperCase();
      const usdAmount = interaction.options.getNumber('amount');
      const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
      const asset = await Asset.findOne({ symbol, type: 'stock', active: true });

      if (!asset) return interaction.editReply(`❌ Stock **${symbol}** not found.`);
      if (user.stockBalance < usdAmount) {
        return interaction.editReply(`❌ Insufficient funds in Stock Account. You have **${formatMoney(user.stockBalance)}**. Use \`/transfer\` to add funds.`);
      }

      const shares = usdAmount / asset.currentPrice;

      let holding = user.stockHoldings.find((h) => h.symbol === symbol);
      if (!holding) {
        user.stockHoldings.push({ symbol, quantity: 0, avgBuyPrice: 0 });
        holding = user.stockHoldings[user.stockHoldings.length - 1];
      }
      const totalCost = holding.quantity * holding.avgBuyPrice + usdAmount;
      const totalQty = holding.quantity + shares;
      holding.avgBuyPrice = totalQty > 0 ? totalCost / totalQty : asset.currentPrice;
      holding.quantity = totalQty;

      user.stockBalance -= usdAmount;
      user.totalSpent += usdAmount;
      user.totalTrades += 1;
      user.xp += 10;

      await checkLevelUp(user);
      await user.save();

      await recordTradePressure(symbol, 'buy', usdAmount);

      await Transaction.create({
        userId: user.userId, type: 'buy_stock', symbol,
        quantity: shares, price: asset.currentPrice, total: usdAmount,
        balanceAfter: user.stockBalance,
      });

      const embed = new EmbedBuilder()
        .setColor(0x00ff88)
        .setTitle('✅ Stock Purchase Successful')
        .addFields(
          { name: 'Stock', value: `${asset.name} (${symbol})`, inline: true },
          { name: 'Shares', value: shares.toFixed(4), inline: true },
          { name: 'Price/Share', value: formatMoney(asset.currentPrice), inline: true },
          { name: 'Total Spent', value: formatMoney(usdAmount), inline: true },
          { name: 'Stock Balance', value: formatMoney(user.stockBalance), inline: true }
        );

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'sell') {
      const symbol = interaction.options.getString('symbol').toUpperCase();
      const shares = interaction.options.getNumber('shares');
      const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
      const asset = await Asset.findOne({ symbol, type: 'stock', active: true });

      if (!asset) return interaction.editReply(`❌ Stock **${symbol}** not found.`);

      const holding = user.stockHoldings.find((h) => h.symbol === symbol);
      if (!holding || holding.quantity < shares) {
        return interaction.editReply(`❌ Not enough shares. You hold: ${holding ? holding.quantity.toFixed(4) : 0} ${symbol}`);
      }

      const usdValue = shares * asset.currentPrice;
      const pnl = (asset.currentPrice - holding.avgBuyPrice) * shares;
      const pnlPct = priceChange(asset.currentPrice, holding.avgBuyPrice);

      holding.quantity -= shares;
      user.stockBalance += usdValue;
      user.totalEarned += usdValue;
      user.totalTrades += 1;
      user.xp += 10;

      await checkLevelUp(user);
      await user.save();

      await recordTradePressure(symbol, 'sell', usdValue);

      await Transaction.create({
        userId: user.userId, type: 'sell_stock', symbol,
        quantity: shares, price: asset.currentPrice, total: usdValue,
        balanceAfter: user.stockBalance,
      });

      const embed = new EmbedBuilder()
        .setColor(pnl >= 0 ? 0x00ff88 : 0xff4545)
        .setTitle(`${pnl >= 0 ? '📈' : '📉'} Stock Sold`)
        .addFields(
          { name: 'Stock', value: `${asset.name} (${symbol})`, inline: true },
          { name: 'Shares Sold', value: shares.toFixed(4), inline: true },
          { name: 'Sale Price', value: formatMoney(asset.currentPrice), inline: true },
          { name: 'Total Received', value: formatMoney(usdValue), inline: true },
          { name: 'P&L', value: `${formatMoney(pnl)} (${formatPercent(pnlPct)})`, inline: true },
          { name: 'Stock Balance', value: formatMoney(user.stockBalance), inline: true }
        );

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'portfolio') {
      const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
      const holdings = user.stockHoldings.filter((h) => h.quantity > 0);

      if (holdings.length === 0) return interaction.editReply('📭 No stock holdings. Use `/stocks buy` to invest!');

      const assets = await Asset.find({ symbol: { $in: holdings.map((h) => h.symbol) }, type: 'stock' });
      const assetMap = {};
      assets.forEach((a) => (assetMap[a.symbol] = a));

      let totalValue = 0, totalCost = 0;
      const lines = [];

      for (const h of holdings) {
        const a = assetMap[h.symbol];
        if (!a) continue;
        const value = h.quantity * a.currentPrice;
        const cost = h.quantity * h.avgBuyPrice;
        const pnl = value - cost;
        const pnlPct = priceChange(a.currentPrice, h.avgBuyPrice);
        totalValue += value;
        totalCost += cost;
        lines.push(`**${h.symbol}** — ${h.quantity.toFixed(4)} sh | Value: ${formatMoney(value)} | P&L: ${formatMoney(pnl)} (${formatPercent(pnlPct)})`);
      }

      const totalPnl = totalValue - totalCost;
      const totalPnlPct = totalCost > 0 ? ((totalPnl / totalCost) * 100) : 0;

      const embed = new EmbedBuilder()
        .setColor(totalPnl >= 0 ? 0x00ff88 : 0xff4545)
        .setTitle('📈 Your Stock Portfolio')
        .setDescription(lines.join('\n'))
        .addFields(
          { name: 'Total Value', value: formatMoney(totalValue), inline: true },
          { name: 'Total P&L', value: `${formatMoney(totalPnl)} (${formatPercent(totalPnlPct)})`, inline: true },
          { name: 'Stock Account', value: formatMoney(user.stockBalance), inline: true }
        );

      return interaction.editReply({ embeds: [embed] });
    }
  },
};
