const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getOrCreateUser, formatMoney, formatPercent, priceChange } = require('../../utils/helpers');
const { recordTradePressure } = require('../../utils/marketEngine');
const Asset = require('../../models/Asset');
const Transaction = require('../../models/Transaction');
const { checkLevelUp } = require('../../utils/jobs');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('crypto')
    .setDescription('Crypto trading')
    .addSubcommand((sub) =>
      sub
        .setName('list')
        .setDescription('List all available cryptocurrencies')
    )
    .addSubcommand((sub) =>
      sub
        .setName('price')
        .setDescription('Check the price of a crypto')
        .addStringOption((o) => o.setName('symbol').setDescription('Crypto symbol').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('buy')
        .setDescription('Buy crypto')
        .addStringOption((o) => o.setName('symbol').setDescription('Symbol').setRequired(true))
        .addNumberOption((o) => o.setName('amount').setDescription('USD amount to spend').setRequired(true).setMinValue(1))
    )
    .addSubcommand((sub) =>
      sub
        .setName('sell')
        .setDescription('Sell crypto')
        .addStringOption((o) => o.setName('symbol').setDescription('Symbol').setRequired(true))
        .addNumberOption((o) => o.setName('quantity').setDescription('Quantity to sell').setRequired(true).setMinValue(0.000001))
    )
    .addSubcommand((sub) =>
      sub
        .setName('portfolio')
        .setDescription('View your crypto portfolio')
    ),

  async execute(interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      const assets = await Asset.find({ type: 'crypto', active: true }).sort({ marketCap: -1 });
      if (assets.length === 0) return interaction.editReply('❌ No cryptocurrencies listed yet. Ask an admin to add some!');

      const lines = assets.map((a) => {
        const chg = priceChange(a.currentPrice, a.previousPrice);
        const arrow = chg >= 0 ? '🟢' : '🔴';
        return `${arrow} **${a.symbol}** — ${formatMoney(a.currentPrice)} (${formatPercent(chg)}) | MCap: ${formatMoney(a.marketCap)}`;
      });

      const embed = new EmbedBuilder()
        .setColor(0xf7931a)
        .setTitle('₿ Cryptocurrency Market')
        .setDescription(lines.join('\n'))
        .setFooter({ text: 'Prices update every minute' })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'price') {
      const symbol = interaction.options.getString('symbol').toUpperCase();
      const asset = await Asset.findOne({ symbol, type: 'crypto', active: true });
      if (!asset) return interaction.editReply(`❌ Crypto **${symbol}** not found.`);

      const chg = priceChange(asset.currentPrice, asset.previousPrice);
      const chg24 = asset.openPrice ? priceChange(asset.currentPrice, asset.openPrice) : 0;

      const embed = new EmbedBuilder()
        .setColor(chg >= 0 ? 0x00ff88 : 0xff4545)
        .setTitle(`₿ ${asset.name} (${asset.symbol})`)
        .addFields(
          { name: 'Price', value: formatMoney(asset.currentPrice), inline: true },
          { name: '1m Change', value: formatPercent(chg), inline: true },
          { name: '24h Change', value: formatPercent(chg24), inline: true },
          { name: 'Market Cap', value: formatMoney(asset.marketCap), inline: true },
          { name: '24h Volume', value: formatMoney(asset.totalVolume24h), inline: true },
          { name: 'Volatility', value: `${(asset.volatility * 100).toFixed(1)}%`, inline: true },
          { name: 'Description', value: asset.description || 'N/A', inline: false }
        );

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'buy') {
      const symbol = interaction.options.getString('symbol').toUpperCase();
      const usdAmount = interaction.options.getNumber('amount');
      const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
      const asset = await Asset.findOne({ symbol, type: 'crypto', active: true });

      if (!asset) return interaction.editReply(`❌ Crypto **${symbol}** not found.`);
      if (user.cryptoBalance < usdAmount) {
        return interaction.editReply(`❌ Insufficient funds in Crypto Account. You have **${formatMoney(user.cryptoBalance)}**. Use \`/transfer\` to add funds.`);
      }

      const quantity = usdAmount / asset.currentPrice;

      // Update holdings (weighted avg)
      let holding = user.cryptoHoldings.find((h) => h.symbol === symbol);
      if (!holding) {
        user.cryptoHoldings.push({ symbol, quantity: 0, avgBuyPrice: 0 });
        holding = user.cryptoHoldings[user.cryptoHoldings.length - 1];
      }
      const totalCost = holding.quantity * holding.avgBuyPrice + usdAmount;
      const totalQty = holding.quantity + quantity;
      holding.avgBuyPrice = totalQty > 0 ? totalCost / totalQty : asset.currentPrice;
      holding.quantity = totalQty;

      user.cryptoBalance -= usdAmount;
      user.totalSpent += usdAmount;
      user.totalTrades += 1;
      user.xp += 10;

      await checkLevelUp(user);
      await user.save();

      // Record market impact
      await recordTradePressure(symbol, 'buy', usdAmount);

      // Log transaction
      await Transaction.create({
        userId: user.userId,
        type: 'buy_crypto',
        symbol,
        quantity,
        price: asset.currentPrice,
        total: usdAmount,
        balanceAfter: user.cryptoBalance,
      });

      const embed = new EmbedBuilder()
        .setColor(0x00ff88)
        .setTitle('✅ Crypto Purchase Successful')
        .addFields(
          { name: 'Asset', value: `${asset.name} (${symbol})`, inline: true },
          { name: 'Quantity', value: quantity.toFixed(6), inline: true },
          { name: 'Price', value: formatMoney(asset.currentPrice), inline: true },
          { name: 'Total Spent', value: formatMoney(usdAmount), inline: true },
          { name: 'Crypto Balance', value: formatMoney(user.cryptoBalance), inline: true },
          { name: 'Total Holdings', value: `${holding.quantity.toFixed(6)} ${symbol}`, inline: true }
        );

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'sell') {
      const symbol = interaction.options.getString('symbol').toUpperCase();
      const quantity = interaction.options.getNumber('quantity');
      const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
      const asset = await Asset.findOne({ symbol, type: 'crypto', active: true });

      if (!asset) return interaction.editReply(`❌ Crypto **${symbol}** not found.`);

      const holding = user.cryptoHoldings.find((h) => h.symbol === symbol);
      if (!holding || holding.quantity < quantity) {
        return interaction.editReply(`❌ You don't have enough **${symbol}**. Holdings: ${holding ? holding.quantity.toFixed(6) : 0}`);
      }

      const usdValue = quantity * asset.currentPrice;
      const pnl = (asset.currentPrice - holding.avgBuyPrice) * quantity;
      const pnlPct = priceChange(asset.currentPrice, holding.avgBuyPrice);

      holding.quantity -= quantity;
      user.cryptoBalance += usdValue;
      user.totalEarned += usdValue;
      user.totalTrades += 1;
      user.xp += 10;

      await checkLevelUp(user);
      await user.save();

      await recordTradePressure(symbol, 'sell', usdValue);

      await Transaction.create({
        userId: user.userId,
        type: 'sell_crypto',
        symbol,
        quantity,
        price: asset.currentPrice,
        total: usdValue,
        balanceAfter: user.cryptoBalance,
      });

      const embed = new EmbedBuilder()
        .setColor(pnl >= 0 ? 0x00ff88 : 0xff4545)
        .setTitle(`${pnl >= 0 ? '📈' : '📉'} Crypto Sold`)
        .addFields(
          { name: 'Asset', value: `${asset.name} (${symbol})`, inline: true },
          { name: 'Quantity Sold', value: quantity.toFixed(6), inline: true },
          { name: 'Sale Price', value: formatMoney(asset.currentPrice), inline: true },
          { name: 'Total Received', value: formatMoney(usdValue), inline: true },
          { name: 'P&L', value: `${formatMoney(pnl)} (${formatPercent(pnlPct)})`, inline: true },
          { name: 'Crypto Balance', value: formatMoney(user.cryptoBalance), inline: true }
        );

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'portfolio') {
      const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
      const holdings = user.cryptoHoldings.filter((h) => h.quantity > 0);

      if (holdings.length === 0) {
        return interaction.editReply('📭 You have no crypto holdings. Buy some with `/crypto buy`!');
      }

      const assets = await Asset.find({ symbol: { $in: holdings.map((h) => h.symbol) }, type: 'crypto' });
      const assetMap = {};
      assets.forEach((a) => (assetMap[a.symbol] = a));

      let totalValue = 0;
      let totalCost = 0;
      const lines = [];

      for (const h of holdings) {
        const a = assetMap[h.symbol];
        if (!a) continue;
        const value = h.quantity * a.currentPrice;
        const cost = h.quantity * h.avgBuyPrice;
        const pnl = value - cost;
        const pnlPct = priceChange(a.currentPrice, h.avgBuyPrice);
        totalValue += value;
        totalCost += cost;
        lines.push(`**${h.symbol}** — ${h.quantity.toFixed(6)} | Value: ${formatMoney(value)} | P&L: ${formatMoney(pnl)} (${formatPercent(pnlPct)})`);
      }

      const totalPnl = totalValue - totalCost;
      const totalPnlPct = totalCost > 0 ? ((totalPnl / totalCost) * 100) : 0;

      const embed = new EmbedBuilder()
        .setColor(totalPnl >= 0 ? 0x00ff88 : 0xff4545)
        .setTitle('₿ Your Crypto Portfolio')
        .setDescription(lines.join('\n'))
        .addFields(
          { name: 'Total Value', value: formatMoney(totalValue), inline: true },
          { name: 'Total P&L', value: `${formatMoney(totalPnl)} (${formatPercent(totalPnlPct)})`, inline: true },
          { name: 'Crypto Account', value: formatMoney(user.cryptoBalance), inline: true }
        );

      return interaction.editReply({ embeds: [embed] });
    }
  },
};
