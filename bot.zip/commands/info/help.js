const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
} = require('discord.js');

const CATEGORIES = {
  overview: {
    label: '🏠 Overview',
    emoji: '🏠',
    description: 'Getting started & bot overview',
    color: 0x5865f2,
    fields: [
      {
        name: '👋 Welcome to EconomyBot!',
        value:
          'A full trading & economy simulation game. Earn money, invest in crypto & stocks, gamble in the casino, and climb the leaderboard!\n\n' +
          '**Quick Start:** Use `/start` to create your account and get starter cash.',
        inline: false,
      },
      {
        name: '💳 Your 5 Accounts',
        value: [
          '`🪙 Wallet` — Liquid cash for everyday spending',
          '`🏦 Bank` — Safe storage (earns interest)',
          '`₿ Crypto` — Fund for crypto trading',
          '`📈 Stock` — Fund for stock trading',
          '`🎰 Casino` — Gambling bankroll',
        ].join('\n'),
        inline: false,
      },
      {
        name: '⭐ Leveling',
        value: 'Earn XP from working, trading, casino, and daily rewards. Higher levels unlock better jobs and bigger daily payouts.',
        inline: false,
      },
      {
        name: '📊 Market',
        value: 'Prices update every minute based on real buy/sell pressure, volatility, and market trends. Your trades actually move the market!',
        inline: false,
      },
    ],
  },

  economy: {
    label: '💰 Economy',
    emoji: '💰',
    description: 'Wallet, bank, transfers & daily',
    color: 0x00d4aa,
    fields: [
      {
        name: '`/start`',
        value: 'Create your account and receive **$1,000** starter cash in your wallet.',
        inline: false,
      },
      {
        name: '`/balance [user]`',
        value: 'View all 5 account balances at a glance.',
        inline: false,
      },
      {
        name: '`/transfer <from> <to> <amount>`',
        value: 'Move funds between any two of your accounts.\n*Example: `/transfer wallet cryptoBalance 500`*',
        inline: false,
      },
      {
        name: '`/daily`',
        value: 'Claim your daily reward — scales up with your level. 24h cooldown.',
        inline: false,
      },
    ],
  },

  work: {
    label: '💼 Work & Jobs',
    emoji: '💼',
    description: 'Jobs, working, and leveling up',
    color: 0xf39c12,
    fields: [
      {
        name: '`/work jobs`',
        value: 'Browse jobs available at your current level.',
        inline: false,
      },
      {
        name: '`/work join <job_id>`',
        value: 'Join a job. You must meet the level requirement.',
        inline: false,
      },
      {
        name: '`/work do`',
        value: 'Perform your job and earn money + XP. Has a cooldown per job tier.',
        inline: false,
      },
      {
        name: '`/work quit`',
        value: 'Quit your current job.',
        inline: false,
      },
      {
        name: '📋 Job Tiers',
        value: [
          '🧤 **Beggar** (Lv 1–4) — $50–150 | 30m cooldown',
          '🛵 **Delivery Driver** (Lv 3–9) — $200–500 | 25m cooldown',
          '💻 **Programmer** (Lv 5–14) — $500–1,200 | 20m cooldown',
          '📈 **Market Analyst** (Lv 10–19) — $1,000–3,000 | 15m cooldown',
          '🏢 **Tech CEO** (Lv 20+) — $5,000–15,000 | 10m cooldown',
        ].join('\n'),
        inline: false,
      },
    ],
  },

  crypto: {
    label: '₿ Crypto',
    emoji: '₿',
    description: 'Buy, sell, and track cryptocurrency',
    color: 0xf7931a,
    fields: [
      {
        name: '`/crypto list`',
        value: 'List all available cryptocurrencies with live prices and 24h change.',
        inline: false,
      },
      {
        name: '`/crypto price <symbol>`',
        value: 'Detailed price info, market cap, volume, and volatility.',
        inline: false,
      },
      {
        name: '`/crypto buy <symbol> <amount>`',
        value: 'Spend USD from your **Crypto Account** to buy crypto.\n*Tip: Use `/transfer wallet cryptoBalance` to fund it first.*',
        inline: false,
      },
      {
        name: '`/crypto sell <symbol> <quantity>`',
        value: 'Sell crypto back to USD (goes to your Crypto Account).',
        inline: false,
      },
      {
        name: '`/crypto portfolio`',
        value: 'View all your crypto holdings with current value and P&L.',
        inline: false,
      },
      {
        name: '📊 How Prices Work',
        value: 'Each buy/sell creates pressure that moves the price. Bigger trades = bigger impact. Prices also follow volatility, trends, and mean reversion.',
        inline: false,
      },
    ],
  },

  stocks: {
    label: '📈 Stocks',
    emoji: '📈',
    description: 'Buy, sell, and trade shares',
    color: 0x1e90ff,
    fields: [
      {
        name: '`/stocks list`',
        value: 'View all listed stocks with price and sector.',
        inline: false,
      },
      {
        name: '`/stocks price <symbol>`',
        value: 'Check detailed stock info including 24h change and volume.',
        inline: false,
      },
      {
        name: '`/stocks buy <symbol> <amount>`',
        value: 'Buy shares using funds from your **Stock Account**.\n*Tip: Fund it first with `/transfer wallet stockBalance`.*',
        inline: false,
      },
      {
        name: '`/stocks sell <symbol> <shares>`',
        value: 'Sell shares and receive USD back to your Stock Account.',
        inline: false,
      },
      {
        name: '`/stocks portfolio`',
        value: 'See all your stock holdings with value and P&L.',
        inline: false,
      },
    ],
  },

  charts: {
    label: '📊 Charts',
    emoji: '📊',
    description: 'Price charts for any asset',
    color: 0x9b59b6,
    fields: [
      {
        name: '`/chart <symbol> [type]`',
        value: 'Generate a price chart for any crypto or stock.',
        inline: false,
      },
      {
        name: 'Chart Types',
        value: [
          '🕯️ **Candlestick** — Shows open/high/low/close per minute. Best for spotting trends and reversals.',
          '⛰️ **Mountain** — Smooth area chart. Best for seeing overall price direction.',
        ].join('\n\n'),
        inline: false,
      },
      {
        name: '💡 Tips',
        value: 'Green candles = price went up that tick. Red = went down.\nCharts show up to the last 30–60 data points (minutes).',
        inline: false,
      },
    ],
  },

  casino: {
    label: '🎰 Casino',
    emoji: '🎰',
    description: 'Gambling games',
    color: 0xe74c3c,
    fields: [
      {
        name: '`/casino slots <bet>`',
        value: [
          'Spin the slot machine. Weighted reels.',
          '💎 Triple Diamonds → **10x** | 7️⃣ Triple 7s → **20x jackpot**',
          '⭐ Triple Stars → 7x | 🔔 Triple Bells → 5x',
          'Any other triple → 3x | Two of a kind → 1.5x',
        ].join('\n'),
        inline: false,
      },
      {
        name: '`/casino coinflip <bet> <heads|tails>`',
        value: '50/50 chance. Win = **2x** your bet.',
        inline: false,
      },
      {
        name: '`/casino blackjack <bet>`',
        value: 'Play against the dealer. Dealer hits until 17. Closest to 21 wins. Bust = auto-lose.',
        inline: false,
      },
      {
        name: '`/casino dice <bet> <1-6>`',
        value: 'Guess the dice roll. Correct = **5x** payout. Hardest but highest reward.',
        inline: false,
      },
      {
        name: '⚠️ Casino Funds',
        value: 'Casino games require funds in your **Casino Account**. Transfer from wallet using `/transfer wallet casinoBalance <amount>`.',
        inline: false,
      },
    ],
  },

  profile: {
    label: '🏆 Profile & Stats',
    emoji: '🏆',
    description: 'Profile, leaderboard, and net worth',
    color: 0xffd700,
    fields: [
      {
        name: '`/profile [user]`',
        value: 'View a full financial profile including all balances, holdings with P&L, level/XP bar, job, casino stats, and total net worth.',
        inline: false,
      },
      {
        name: '`/leaderboard [type]`',
        value: [
          'View the top 10 players.',
          '💎 **Net Worth** — Total value across all accounts + holdings',
          '⭐ **Level** — Highest leveled players',
          '🎰 **Casino Wins** — Most casino victories',
        ].join('\n'),
        inline: false,
      },
      {
        name: '💎 Net Worth',
        value: 'Your net worth = Wallet + Bank + Crypto Account + Stock Account + Casino Account + value of all holdings at current market prices.',
        inline: false,
      },
    ],
  },
};

function buildEmbed(categoryKey) {
  const cat = CATEGORIES[categoryKey];
  return new EmbedBuilder()
    .setColor(cat.color)
    .setTitle(`${cat.emoji} ${cat.label}`)
    .setDescription(cat.description)
    .addFields(cat.fields)
    .setFooter({ text: 'EconomyBot • Use the menu below to navigate' });
}

function buildSelectMenu(current) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('help_menu')
      .setPlaceholder('📖 Select a category...')
      .addOptions(
        Object.entries(CATEGORIES).map(([key, cat]) => ({
          label: cat.label,
          description: cat.description,
          value: key,
          default: key === current,
          emoji: cat.emoji,
        }))
      )
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Browse all bot commands and features'),

  async execute(interaction) {
    const startCategory = 'overview';
    const embed = buildEmbed(startCategory);
    const menu = buildSelectMenu(startCategory);

    const reply = await interaction.reply({
      embeds: [embed],
      components: [menu],
      fetchReply: true,
    });

    const collector = reply.createMessageComponentCollector({
      componentType: ComponentType.StringSelect,
      time: 5 * 60 * 1000, // 5 minutes
      filter: (i) => i.user.id === interaction.user.id,
    });

    collector.on('collect', async (i) => {
      const selected = i.values[0];
      await i.update({
        embeds: [buildEmbed(selected)],
        components: [buildSelectMenu(selected)],
      });
    });

    collector.on('end', async () => {
      try {
        await reply.edit({ components: [] });
      } catch {}
    });
  },
};
